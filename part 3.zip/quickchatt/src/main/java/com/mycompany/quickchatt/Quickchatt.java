/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatt;

/**
 *
 * @author matle
 */
import javax.swing.JOptionPane;

public class Quickchatt {
    public static void main(String[] args) {
        Login authSystem = new Login();
        Message messageEngine = new Message();

        new Message("0834578960", "+2783457896", "Did you get the cake?", "08:0:DIDCAKE", "Sent").populateMessageArrays();
        new Message("0838884561", "+27838884567", "Where are you? You are late! I have asked you to be on time.", "08:1:WHERETIME", "Stored").populateMessageArrays();
        new Message("0834484562", "+27834484567", "Yohoooo, I am at your gate.", "08:2:YOHOOGATE", "Disregard").populateMessageArrays();
        new Message("0838884567", "0838884567", "It is dinner time !", "08:3:ITTIME", "Sent").populateMessageArrays();
        new Message("0838884564", "+27838884567", "Ok, I am leaving without you.", "08:4:OKYOU", "Stored").populateMessageArrays();

        JOptionPane.showMessageDialog(null, "Welcome to the QuickChat App!", "QuickChat", JOptionPane.INFORMATION_MESSAGE);
        
        String username = JOptionPane.showInputDialog("Create a Username (Must have _ and max 5 chars):");
        String password = JOptionPane.showInputDialog("Create a Password:");
        
        String registrationOutput = authSystem.registerUser(username, password, "FirstYear", "Student");
        JOptionPane.showMessageDialog(null, registrationOutput);

        if (registrationOutput.contains("is not correctly formatted")) {
            return;
        }

        String loginUser = JOptionPane.showInputDialog("Enter Your Username to Login:");
        String loginPass = JOptionPane.showInputDialog("Enter Your Password to Login:");

        boolean isAuthenticated = authSystem.loginUser(loginUser, loginPass);
        JOptionPane.showMessageDialog(null, authSystem.returnLoginStatus(isAuthenticated));

        if (!isAuthenticated) {
            return;
        }

        String[] menuOptions = {
            "1) Send a New Message", 
            "2) Show Recently Sent Messages", 
            "3) Run Unit Verification Tests", 
            "4) Stored Messages Operations", 
            "5) Quit Application"
        };

        while (true) {
            String selection = (String) JOptionPane.showInputDialog(
                null, 
                "Select a menu option:", 
                "QuickChat Main Menu", 
                JOptionPane.PLAIN_MESSAGE, 
                null, 
                menuOptions, 
                menuOptions[0]
            );

            if (selection == null || selection.contains("5)")) {
                JOptionPane.showMessageDialog(null, "Exiting Application. Goodbye!");
                break;
            }

            if (selection.contains("1)")) {
                String recipientNum = JOptionPane.showInputDialog("Enter Recipient Cell Number:");
                String validationStatus = messageEngine.checkRecipientCell(recipientNum);
                JOptionPane.showMessageDialog(null, validationStatus);
                
                if (!validationStatus.contains("incorrectly formatted")) {
                    String msgText = JOptionPane.showInputDialog("Enter your message content:");
                    JOptionPane.showMessageDialog(null, messageEngine.validateMessageLength(msgText));
                }
            } 
            else if (selection.contains("2)")) {
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            } 
            else if (selection.contains("3)")) {
                String testReport = "--- AUTOMATED UNIT TESTS RESULTS ---\n\n" +
                        "1. Sent Messages Log Check: " + messageEngine.getSentMessagesValue() + "\n" +
                        "2. Longest Stored Message Check: " + messageEngine.displayLongestStoredMessage() + "\n" +
                        "3. ID Search Test (0838884567): " + messageEngine.searchByMessageID("0838884567") + "\n" +
                        "4. Recipient Search Test (+27838884567): " + messageEngine.searchByRecipient("+27838884567") + "\n" +
                        "5. Delete Hash Test: " + messageEngine.deleteMessageByHash("08:1:WHERETIME");
                
                JOptionPane.showMessageDialog(null, testReport, "Test Assertions Matrix", JOptionPane.INFORMATION_MESSAGE);
            } 
            else if (selection.contains("4)")) {
                String[] subOptions = {
                    "a) Display sender and recipient of all stored messages",
                    "b) Display the longest stored message",
                    "c) Search for a message ID and display details",
                    "d) Search stored database entries for a particular recipient",
                    "e) Delete an item from the system using the unique message hash",
                    "f) Display full report listing of all sent messages"
                };

                String subSelection = (String) JOptionPane.showInputDialog(
                    null, 
                    "Choose a Stored Messages sub-feature operation:", 
                    "Stored Messages Sub-Menu", 
                    JOptionPane.PLAIN_MESSAGE, 
                    null, 
                    subOptions, 
                    subOptions[0]
                );

                if (subSelection != null) {
                    if (subSelection.startsWith("a)")) {
                        JOptionPane.showMessageDialog(null, messageEngine.displayStoredSendersAndRecipients());
                    } else if (subSelection.startsWith("b)")) {
                        JOptionPane.showMessageDialog(null, "Longest Stored: " + messageEngine.displayLongestStoredMessage());
                    } else if (subSelection.startsWith("c)")) {
                        String searchID = JOptionPane.showInputDialog("Enter Message ID to Search:");
                        JOptionPane.showMessageDialog(null, "Result: " + messageEngine.searchByMessageID(searchID));
                    } else if (subSelection.startsWith("d)")) {
                        String targetCell = JOptionPane.showInputDialog("Enter Recipient Cell Number:");
                        JOptionPane.showMessageDialog(null, "Result: " + messageEngine.searchByRecipient(targetCell));
                    } else if (subSelection.startsWith("e)")) {
                        String hashInput = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                        JOptionPane.showMessageDialog(null, messageEngine.deleteMessageByHash(hashInput));
                    } else if (subSelection.startsWith("f)")) {
                        JOptionPane.showMessageDialog(null, messageEngine.printSentMessagesReport());
                    }
                }
            }
        }
    }
}