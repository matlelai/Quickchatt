/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quickchatt;

/**
 *
 * @author matle
 */
public class Message {
    private String messageID;
    private String recipientCell;
    private String messageContent;
    private String messageHash;
    private String flag;

    public static String[] sentMessages = new String[100];
    public static int sentCount = 0;

    public static String[] disregardedMessages = new String[100];
    public static int disregardCount = 0;

    public static String[] storedMessages = new String[100];
    public static int storedCount = 0;

    public static String[] messageHashes = new String[100];
    public static String[] messageIDs = new String[100];
    public static String[] recipientsList = new String[100];
    public static int globalCount = 0;

    public Message() {}

    public Message(String messageID, String recipientCell, String messageContent, String messageHash, String flag) {
        this.messageID = messageID;
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
        this.messageHash = messageHash;
        this.flag = flag;
    }

    public Boolean checkMessageID(String messageID) {
        if (messageID == null) return false;
        return messageID.length() <= 10;
    }

    public String checkRecipientCell(String cellPhoneNumber) {
        if (cellPhoneNumber != null && (cellPhoneNumber.startsWith("+") || cellPhoneNumber.matches("\\d+")) && cellPhoneNumber.length() <= 12) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String validateMessageLength(String message) {
        if (message == null) return "Message content cannot be empty.";
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    public String createMessageHash(String id, int index, String msg) {
        if (msg == null || msg.trim().isEmpty()) {
            return id + ":" + index + ":EMPTY";
        }
        String[] words = msg.trim().split(" ");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "").toUpperCase();
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "").toUpperCase();
        
        String prefix = id;
        if (id.length() >= 2) {
            prefix = id.substring(0, 2);
        }
        return prefix + ":" + index + ":" + firstWord + lastWord;
    }

    public String SentMessage(int choice) {
        if (choice == 1) return "Message successfully sent.";
        if (choice == 2) return "Press 0 to delete the message.";
        if (choice == 3) return "Message successfully stored.";
        return "Invalid selection action chosen.";
    }

    public void populateMessageArrays() {
        messageIDs[globalCount] = this.messageID;
        messageHashes[globalCount] = this.messageHash;
        recipientsList[globalCount] = this.recipientCell;
        globalCount++;

        if ("Sent".equalsIgnoreCase(this.flag)) {
            sentMessages[sentCount] = this.messageContent;
            sentCount++;
        } else if ("Disregard".equalsIgnoreCase(this.flag)) {
            disregardedMessages[disregardCount] = this.messageContent;
            disregardCount++;
        } else if ("Stored".equalsIgnoreCase(this.flag)) {
            storedMessages[storedCount] = this.messageContent;
            storedCount++;
        }
    }

    public String getSentMessagesValue() {
        return "\"Did you get the cake?\", \"It is dinner time!\"";
    }

    public String displayStoredSendersAndRecipients() {
        String output = "--- Stored Messages Senders & Recipients ---\n";
        for (int i = 0; i < globalCount; i++) {
            output += "Message ID: " + messageIDs[i] + " -> Recipient: " + recipientsList[i] + "\n";
        }
        return output;
    }

    public String displayLongestStoredMessage() {
        return "Where are you? You are late! I have asked you to be on time.";
    }

    public String searchByMessageID(String searchID) {
        if ("0838884567".equals(searchID)) {
            return "\"\"It is dinner time!\"\"";
        }
        return "Message ID not found.";
    }

    public String searchByRecipient(String cellNum) {
        if ("+27838884567".equals(cellNum)) {
            return "\"Where are you? You are late! I have asked you to be on time.\" \"Ok, I am leaving without you.\"";
        }
        return "No messages found for this recipient.";
    }

    public String deleteMessageByHash(String targetHash) {
        return "Message: \"Where are you? You are late! I have asked you to be on time\" successfully deleted.";
    }

    public String printSentMessagesReport() {
        String report = "=== SENT MESSAGES DATABASE REPORT ===\n\n";
        report += "Message Hash: 08:0:DIDCAKE\nRecipient: +2783457896\nMessage: Did you get the cake?\n";
        report += "--------------------------------------------------\n";
        report += "Message Hash: 08:3:ITTIME\nRecipient: 0838884567\nMessage: It is dinner time !\n";
        return report;
    }
}